#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Writes the complete semicolon-separated tag list from CSV to ID3 TIT1.
TPE2 ("Block") and all other ID3 frames remain unchanged.
"""

from __future__ import annotations
import argparse
import csv
from pathlib import Path

try:
    from mutagen.id3 import ID3, ID3NoHeaderError, TIT1
except ImportError:
    print("Mutagen is not installed.")
    print("Run: py -m pip install mutagen")
    raise SystemExit(2)

def read_rows(csv_path: Path):
    with csv_path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f, delimiter=";")
        required = {"FILEPATH", "TIT1"}
        missing = required - set(reader.fieldnames or [])
        if missing:
            raise ValueError("Missing CSV columns: " + ", ".join(sorted(missing)))
        return list(reader)

def read_tit1(path: Path):
    try:
        tags = ID3(path)
    except ID3NoHeaderError:
        return []
    frames = tags.getall("TIT1")
    return [str(x).strip() for x in (frames[0].text if frames else []) if str(x).strip()]

def write_tit1(path: Path, values):
    try:
        tags = ID3(path)
    except ID3NoHeaderError:
        tags = ID3()
    tags.delall("TIT1")
    tags.add(TIT1(encoding=3, text=values))
    # ID3v2.4 preserves multiple TIT1 values.
    tags.save(path, v2_version=4)

def main():
    parser = argparse.ArgumentParser()
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check", action="store_true")
    mode.add_argument("--apply", action="store_true")
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--csv", default="update_tags.csv")
    args = parser.parse_args()

    rows = read_rows(Path(args.csv).resolve())
    if args.limit > 0:
        rows = rows[:args.limit]

    changed = unchanged = missing = errors = 0
    print("MODE:", "WRITE" if args.apply else "CHECK ONLY")
    print("-" * 100)

    for i, row in enumerate(rows, 1):
        path = Path((row.get("FILEPATH") or "").strip().strip('"'))
        values = [x.strip() for x in (row.get("TIT1") or "").split(";") if x.strip()]

        if not path.exists():
            missing += 1
            print(f"{i:>4}. FILE NOT FOUND | {path}")
            continue
        if path.suffix.lower() != ".mp3":
            errors += 1
            print(f"{i:>4}. NOT MP3        | {path}")
            continue
        if not values:
            errors += 1
            print(f"{i:>4}. EMPTY TIT1     | {path}")
            continue

        try:
            old = read_tit1(path)
            if old == values:
                unchanged += 1
                print(f"{i:>4}. UNCHANGED      | {path.name}")
                continue

            if args.apply:
                write_tit1(path, values)
                verify = read_tit1(path)
                if verify != values:
                    raise RuntimeError(f"Verification failed: {verify!r}")
                status = "UPDATED"
            else:
                status = "WILL UPDATE"

            changed += 1
            print(f"{i:>4}. {status:<14} | {path.name}")
        except Exception as exc:
            errors += 1
            print(f"{i:>4}. ERROR          | {type(exc).__name__}: {exc} | {path}")

    print("-" * 100)
    print("Rows:", len(rows))
    print("Changes:", changed)
    print("Unchanged:", unchanged)
    print("Missing files:", missing)
    print("Errors:", errors)
    return 1 if missing or errors else 0

if __name__ == "__main__":
    raise SystemExit(main())
