@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
    py update_tags.py --apply --limit 10
) else (
    python update_tags.py --apply --limit 10
)
echo.
pause
