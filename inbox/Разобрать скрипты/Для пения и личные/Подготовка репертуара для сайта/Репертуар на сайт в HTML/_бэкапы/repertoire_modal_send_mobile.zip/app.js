const TAG_LABELS = {
  "все":"Все",
  "популярное":"Самые популярные",
  "лаунж":"Лаунж",
  "энергичные":"Энергичные",
  "медляки":"Медляки",
  "танцы":"Танцы",
  "рок":"Рок",
  "русские":"Русские",
  "зарубежные":"Зарубежные",
  "кавер":"Каверы",
  "акустика":"Акустика",
  "ремикс":"Ремиксы"
};

const preferredTags = [
  "все","популярное","лаунж","энергичные","медляки",
  "танцы","рок","русские","зарубежные","кавер"
];

let songs = [];
let activeTag = "все";
let query = "";
const selected = new Set();

const tagsEl = document.getElementById("tags");
const listEl = document.getElementById("song-list");
const countEl = document.getElementById("count");
const searchEl = document.getElementById("search");
const resetEl = document.getElementById("reset");
const selectVisibleEl = document.getElementById("select-visible");
const clearSelectedEl = document.getElementById("clear-selected");
const sendTelegramEl = document.getElementById("send-telegram");
const selectionBarEl = document.getElementById("selection-bar");
const selectedCountEl = document.getElementById("selected-count");
const template = document.getElementById("song-template");

function songId(song){
  return `${song.artist}\u0000${song.title}`;
}

function pluralize(n){
  const n10=n%10,n100=n%100;
  if(n10===1 && n100!==11) return `${n} композиция`;
  if([2,3,4].includes(n10) && ![12,13,14].includes(n100)) return `${n} композиции`;
  return `${n} композиций`;
}

function renderTags(){
  tagsEl.innerHTML="";
  preferredTags.forEach(tag=>{
    if(tag!=="все" && !songs.some(song=>(song.tags||[]).includes(tag))) return;
    const button=document.createElement("button");
    button.type="button";
    button.className="tag-button"+(activeTag===tag?" active":"");
    button.textContent="#"+(TAG_LABELS[tag]||tag);
    button.addEventListener("click",()=>{
      activeTag=tag;
      renderTags();
      renderSongs();
    });
    tagsEl.appendChild(button);
  });
}

function filteredSongs(){
  const q=query.trim().toLowerCase();
  return songs.filter(song=>{
    const matchesTag=activeTag==="все" || (song.tags||[]).includes(activeTag);
    const matchesText=!q || `${song.artist} ${song.title}`.toLowerCase().includes(q);
    return matchesTag && matchesText;
  }).sort((a,b)=>{
    const artistCompare=(a.artist||"").localeCompare(b.artist||"","ru");
    return artistCompare || (a.title||"").localeCompare(b.title||"","ru");
  });
}

function renderSongs(){
  const visible=filteredSongs();
  countEl.textContent=pluralize(visible.length);
  listEl.innerHTML="";

  if(!visible.length){
    const empty=document.createElement("div");
    empty.className="empty";
    empty.textContent="Ничего не найдено. Попробуйте другой фильтр или запрос.";
    listEl.appendChild(empty);
    updateSelectionBar();
    return;
  }

  visible.forEach(song=>{
    const node=template.content.cloneNode(true);
    const input=node.querySelector(".song-checkbox");
    const text=node.querySelector(".song-text");
    const id=songId(song);

    input.checked=selected.has(id);
    input.setAttribute("aria-label",`${song.artist} — ${song.title}`);
    text.textContent=`${song.artist} — ${song.title}`;

    input.addEventListener("change",()=>{
      input.checked ? selected.add(id) : selected.delete(id);
      updateSelectionBar();
    });

    listEl.appendChild(node);
  });

  updateSelectionBar();
}

function updateSelectionBar(){
  const n=selected.size;
  selectionBarEl.hidden=n===0;
  selectedCountEl.textContent=`Выбрано: ${n}`;
}

function selectedSongs(){
  return songs
    .filter(song=>selected.has(songId(song)))
    .sort((a,b)=>(a.artist||"").localeCompare(b.artist||"","ru") || (a.title||"").localeCompare(b.title||"","ru"));
}

function buildMessage(){
  const items=selectedSongs().map((song,index)=>`${index+1}. ${song.artist} — ${song.title}`);
  return `Здравствуйте, Андрей! Хотел(а) бы услышать следующие песни:\n\n${items.join("\n")}`;
}

const sendModalEl=document.getElementById("send-modal");
const modalCopyEl=document.getElementById("modal-copy");
const modalCopyStatusEl=document.getElementById("modal-copy-status");
const modalSongListEl=document.getElementById("modal-song-list");

function openSendModal(){
  const chosen=selectedSongs();
  if(!chosen.length) return;

  modalSongListEl.innerHTML="";
  chosen.forEach((song,index)=>{
    const item=document.createElement("div");
    item.className="selected-song-item";
    item.textContent=`${index+1}. ${song.artist} — ${song.title}`;
    modalSongListEl.appendChild(item);
  });

  modalCopyEl.textContent="Скопировать список";
  modalCopyStatusEl.textContent="";
  sendModalEl.hidden=false;
  document.body.classList.add("modal-open");
}

function closeSendModal(){
  sendModalEl.hidden=true;
  document.body.classList.remove("modal-open");
}

async function copySelectedList(){
  const message=buildMessage();
  let ok=false;

  if(navigator.clipboard && window.isSecureContext){
    try{
      await navigator.clipboard.writeText(message);
      ok=true;
    }catch(error){}
  }

  if(!ok){
    const area=document.createElement("textarea");
    area.value=message;
    area.style.position="fixed";
    area.style.left="-9999px";
    area.style.top="0";
    document.body.appendChild(area);
    area.focus();
    area.select();

    try{
      ok=document.execCommand("copy");
    }catch(error){
      ok=false;
    }

    area.remove();
  }

  if(ok){
    modalCopyEl.textContent="Скопировано ✓";
    modalCopyStatusEl.textContent="Список скопирован. Теперь выберите удобный мессенджер.";
  }else{
    modalCopyEl.textContent="Не удалось скопировать";
    modalCopyStatusEl.textContent="Браузер запретил копирование. Откройте список ниже и скопируйте его вручную.";
  }
}

sendTelegramEl.addEventListener("click",openSendModal);
modalCopyEl.addEventListener("click",copySelectedList);

sendModalEl.addEventListener("click",event=>{
  if(event.target.matches("[data-close-modal]")) closeSendModal();
});

document.addEventListener("keydown",event=>{
  if(event.key==="Escape" && !sendModalEl.hidden) closeSendModal();
});

searchEl.addEventListener("input",event=>{
  query=event.target.value;
  renderSongs();
});

resetEl.addEventListener("click",()=>{
  activeTag="все";
  query="";
  searchEl.value="";
  renderTags();
  renderSongs();
});

selectVisibleEl.addEventListener("click",()=>{
  filteredSongs().forEach(song=>selected.add(songId(song)));
  renderSongs();
});

clearSelectedEl.addEventListener("click",()=>{
  selected.clear();
  renderSongs();
});

function init(){
  if(!Array.isArray(window.SONGS)){
    countEl.textContent="Ошибка загрузки";
    listEl.innerHTML='<div class="error">Не удалось загрузить songs.js.</div>';
    return;
  }

  songs=window.SONGS;
  renderTags();
  renderSongs();
}


const toolbarEl=document.getElementById("toolbar");
const mobileTagsToggleEl=document.getElementById("mobile-tags-toggle");

function updateMobileToolbar(){
  if(window.innerWidth>720){
    toolbarEl.classList.remove("mobile-compact","tags-open");
    mobileTagsToggleEl.setAttribute("aria-expanded","false");
    return;
  }

  const shouldCompact=window.scrollY>170;
  toolbarEl.classList.toggle("mobile-compact",shouldCompact);

  if(!shouldCompact){
    toolbarEl.classList.remove("tags-open");
    mobileTagsToggleEl.setAttribute("aria-expanded","false");
  }
}

mobileTagsToggleEl.addEventListener("click",()=>{
  const isOpen=toolbarEl.classList.toggle("tags-open");
  mobileTagsToggleEl.setAttribute("aria-expanded",isOpen ? "true" : "false");
});

window.addEventListener("scroll",updateMobileToolbar,{passive:true});
window.addEventListener("resize",updateMobileToolbar);
updateMobileToolbar();

init();
