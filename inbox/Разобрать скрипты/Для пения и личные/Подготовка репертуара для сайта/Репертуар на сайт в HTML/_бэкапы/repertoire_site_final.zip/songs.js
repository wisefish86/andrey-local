window.REPERTOIRE={
  "config": {
    "settings": {
      "hit_rating": 242,
      "csv_delimiter": ";"
    },
    "groups": {
      "language": {
        "title": "Язык",
        "weight": 100,
        "color": "#DCEBFF"
      },
      "mood": {
        "title": "Настроение",
        "weight": 70,
        "color": "#FFE8C7"
      },
      "genre": {
        "title": "Жанр",
        "weight": 50,
        "color": "#E8E8E8"
      },
      "event": {
        "title": "События",
        "weight": 30,
        "color": "#FFD6E7"
      }
    },
    "tags": {
      "русские": {
        "group": "language",
        "weight": 100
      },
      "иностранные": {
        "group": "language",
        "weight": 90
      },
      "медляки": {
        "group": "mood",
        "weight": 80
      },
      "танцы": {
        "group": "mood",
        "weight": 70
      },
      "динамичный фон": {
        "group": "mood",
        "weight": 60
      },
      "легкий фон": {
        "group": "mood",
        "weight": 50
      },
      "рок": {
        "group": "genre",
        "weight": 50
      }
    },
    "replace": {
      "Я-рус": "русские",
      "Я-англ": "иностранные",
      "Я-ин": "иностранные",
      "к-Релакс": "легкий фон",
      "к-Лаунж": "легкий фон",
      "к-Сред": "легкий фон",
      "к-Медляк": "медляки",
      "к-Динамич": "динамичный фон",
      "к-Танцы&фон": [
        "танцы",
        "динамичный фон"
      ]
    }
  },
  "songs": [
    {
      "artist": "ШнАпS Band",
      "title": "Батарейка (cover)",
      "rating": 255,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Сосо Павлиашвили",
      "title": "Небо на ладони",
      "rating": 255,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Пицца",
      "title": "Оружие",
      "rating": 255,
      "tags": [
        "русские",
        "медляки"
      ]
    },
    {
      "artist": "Паскаль",
      "title": "Шёлковое сердце",
      "rating": 255,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Мурат Насыров",
      "title": "Я это ты",
      "rating": 255,
      "tags": [
        "русские",
        "медляки"
      ]
    },
    {
      "artist": "Макс Барских",
      "title": "Туманы",
      "rating": 255,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Леприконсы",
      "title": "Хали-гали, Паратрупер",
      "rating": 255,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Леонид Агутин, Анжелика Варум",
      "title": "Я буду всегда с тобой",
      "rating": 255,
      "tags": [
        "русские",
        "легкий фон"
      ]
    },
    {
      "artist": "Леонид Агутин",
      "title": "Хоп хэй лала лэй",
      "rating": 255,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Леонид Агутин",
      "title": "Самба",
      "rating": 255,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Леонид Агутин",
      "title": "Половина сердца",
      "rating": 255,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Леонид Агутин",
      "title": "Оле-оле",
      "rating": 255,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Леонид Агутин",
      "title": "На сиреневой луне",
      "rating": 255,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Иванушки International",
      "title": "Тополиный Пух",
      "rating": 255,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Женя Трофимов",
      "title": "Самолеты (remix)",
      "rating": 255,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Женя Трофимов",
      "title": "Поезда",
      "rating": 255,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Градусы",
      "title": "Режиссёр",
      "rating": 255,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Валерий Меладзе",
      "title": "Небеса",
      "rating": 255,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Валентин Стрыкало",
      "title": "Наше лето",
      "rating": 255,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Братья Грим",
      "title": "Ресницы",
      "rating": 255,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Алексей Чумаков",
      "title": "Тут и там",
      "rating": 255,
      "tags": [
        "русские",
        "легкий фон"
      ]
    },
    {
      "artist": "Алексей Чумаков",
      "title": "Счастье",
      "rating": 255,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Александр Иванов",
      "title": "Боже, Какой Пустяк",
      "rating": 255,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Tito & Tarantula",
      "title": "After Dark",
      "rating": 255,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "The Overtones",
      "title": "Pretty Woman (cover)",
      "rating": 255,
      "tags": [
        "иностранные",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Sting",
      "title": "Every Breath You Take",
      "rating": 255,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Sting",
      "title": "Englishman In New York",
      "rating": 255,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Robbie Williams",
      "title": "Feel",
      "rating": 255,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "Reamonn",
      "title": "Tonight",
      "rating": 255,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Ofenbach",
      "title": "Be Mine",
      "rating": 255,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "Mr. Credo",
      "title": "Чудная долина",
      "rating": 255,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Maroon 5",
      "title": "She Will Be Loved",
      "rating": 255,
      "tags": [
        "иностранные",
        "медляки"
      ]
    },
    {
      "artist": "Maneskin",
      "title": "Beggin'",
      "rating": 255,
      "tags": [
        "иностранные",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "LOBODA",
      "title": "Текила-любовь (cover)",
      "rating": 255,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Kaleo",
      "title": "Way Down We Go",
      "rating": 255,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "JP Cooper",
      "title": "She's On My Mind",
      "rating": 255,
      "tags": [
        "иностранные",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Jony",
      "title": "Комета",
      "rating": 255,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Jony",
      "title": "Комета (cover)",
      "rating": 255,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Goartur",
      "title": "Иностранец (cover)",
      "rating": 255,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Giorgos Mazonakis",
      "title": "Sabbato",
      "rating": 255,
      "tags": [
        "иностранные",
        "медляки"
      ]
    },
    {
      "artist": "Galibri & Mavik",
      "title": "Федерико Феллини",
      "rating": 255,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Enrique Iglesias",
      "title": "Love To See You Cry",
      "rating": 255,
      "tags": [
        "иностранные",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Chebanov",
      "title": "Ночь (cover)",
      "rating": 255,
      "tags": [
        "русские",
        "легкий фон"
      ]
    },
    {
      "artist": "Berk & The Virtual Band",
      "title": "Sex Bomb (cover)",
      "rating": 255,
      "tags": [
        "иностранные",
        "легкий фон"
      ]
    },
    {
      "artist": "Andy Williams",
      "title": "Can't Take My Eyes Off You",
      "rating": 255,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Adriano Celentano",
      "title": "Soli",
      "rating": 255,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Шура",
      "title": "Не верь слезам",
      "rating": 242,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "ШнАпS Band",
      "title": "Улыбайся (cover)",
      "rating": 242,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "ШнАпS Band",
      "title": "Районы-кварталы (cover)",
      "rating": 242,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Чай вдвоём",
      "title": "Ласковая моя",
      "rating": 242,
      "tags": [
        "русские",
        "медляки"
      ]
    },
    {
      "artist": "Сплин",
      "title": "Моё сердце",
      "rating": 242,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Сплин",
      "title": "Выхода нет",
      "rating": 242,
      "tags": [
        "русские",
        "легкий фон"
      ]
    },
    {
      "artist": "Смысловые галлюцинации",
      "title": "Вечно молодой",
      "rating": 242,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Севак Ханагян",
      "title": "Когда мы с тобой",
      "rating": 242,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Севак Ханагян",
      "title": "Жди меня там",
      "rating": 242,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Севак Ханагян",
      "title": "Если Вдруг",
      "rating": 242,
      "tags": [
        "русские",
        "легкий фон"
      ]
    },
    {
      "artist": "Руки вверх",
      "title": "18 мне уже",
      "rating": 242,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Пицца",
      "title": "Романс",
      "rating": 242,
      "tags": [
        "русские",
        "легкий фон"
      ]
    },
    {
      "artist": "Пицца",
      "title": "Пятница",
      "rating": 242,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Пицца",
      "title": "Лифт",
      "rating": 242,
      "tags": [
        "русские",
        "легкий фон"
      ]
    },
    {
      "artist": "Олег Кензов",
      "title": "По кайфу",
      "rating": 242,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Нодар Ревия",
      "title": "Это здорово (cover)",
      "rating": 242,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Нодар Ревия",
      "title": "Не говори ему",
      "rating": 242,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Нодар Ревия",
      "title": "Лала",
      "rating": 242,
      "tags": [
        "русские",
        "легкий фон"
      ]
    },
    {
      "artist": "Николай Носков",
      "title": "Это здорово (медляк)",
      "rating": 242,
      "tags": [
        "русские",
        "легкий фон"
      ]
    },
    {
      "artist": "Михей и Джуманджи",
      "title": "Сука-любовь",
      "rating": 242,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Михаил Шуфутинский",
      "title": "Левый берег Дона",
      "rating": 242,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Михаил Боярский",
      "title": "Спасибо, родная",
      "rating": 242,
      "tags": [
        "русские",
        "медляки"
      ]
    },
    {
      "artist": "Мари Краймбрери, Ф. Киркоров",
      "title": "Первый снег (cover)",
      "rating": 242,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Максим Круженков, Hi-Fi",
      "title": "Седьмой лепесток (cover)",
      "rating": 242,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Макс Барских",
      "title": "Моя любовь",
      "rating": 242,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Макс Барских",
      "title": "Берега",
      "rating": 242,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Ляпис Трубецкой",
      "title": "Шут",
      "rating": 242,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Леонид Агутин",
      "title": "Голос высокой травы",
      "rating": 242,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Ленинград",
      "title": "Рыба моей мечты",
      "rating": 242,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Ленинград",
      "title": "WWW",
      "rating": 242,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Ласковый май",
      "title": "Детство",
      "rating": 242,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Ласковый май",
      "title": "Белые розы",
      "rating": 242,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Король и Шут",
      "title": "Танец злобного гения (acoustic)",
      "rating": 242,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Король и Шут",
      "title": "Кукла колдуна",
      "rating": 242,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Король и Шут",
      "title": "Камнем по голове",
      "rating": 242,
      "tags": []
    },
    {
      "artist": "Иракли",
      "title": "Капли Абсента",
      "rating": 242,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Игорь Саруханов",
      "title": "Желаю тебе",
      "rating": 242,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Звонкий",
      "title": "Голоса",
      "rating": 242,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Звери",
      "title": "Районы-кварталы",
      "rating": 242,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Доминик Джокер",
      "title": "Если ты со мной",
      "rating": 242,
      "tags": [
        "русские",
        "медляки"
      ]
    },
    {
      "artist": "Дмитрий Колдун",
      "title": "Корабли",
      "rating": 242,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Дима Билан",
      "title": "Молния",
      "rating": 242,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "ДДТ",
      "title": "Это всё",
      "rating": 242,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Григорий Лепс",
      "title": "Натали",
      "rating": 242,
      "tags": [
        "русские",
        "медляки"
      ]
    },
    {
      "artist": "Владимир Пресняков",
      "title": "Всё нормально у хулигана",
      "rating": 242,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Владимир Кузьмин",
      "title": "Эй, красотка",
      "rating": 242,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Валерий Сюткин",
      "title": "7000 над землёй",
      "rating": 242,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Валерий Меладзе",
      "title": "Се ля ви",
      "rating": 242,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Валерий Меладзе",
      "title": "Притяженья больше нет",
      "rating": 242,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Валерий Меладзе",
      "title": "Красиво",
      "rating": 242,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Валерий Леонтьев",
      "title": "Сокровища Чёрного моря",
      "rating": 242,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Бумбокс",
      "title": "Та, что",
      "rating": 242,
      "tags": [
        "русские",
        "легкий фон"
      ]
    },
    {
      "artist": "Браво",
      "title": "Я - то, что надо (cover)",
      "rating": 242,
      "tags": [
        "русские",
        "легкий фон"
      ]
    },
    {
      "artist": "Браво",
      "title": "Ветер знает",
      "rating": 242,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Батырхан Шукенов",
      "title": "Твои шаги",
      "rating": 242,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Баста",
      "title": "Сансара",
      "rating": 242,
      "tags": [
        "русские",
        "медляки"
      ]
    },
    {
      "artist": "Антон Беляев",
      "title": "Лететь (cover)",
      "rating": 242,
      "tags": [
        "русские",
        "легкий фон"
      ]
    },
    {
      "artist": "Андрей Губин",
      "title": "Ночь",
      "rating": 242,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Андрей Губин",
      "title": "Девушки как звезды",
      "rating": 242,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "А-Мега",
      "title": "Лететь",
      "rating": 242,
      "tags": [
        "русские",
        "медляки"
      ]
    },
    {
      "artist": "Александр Розенбаум",
      "title": "Ау (cover)",
      "rating": 242,
      "tags": [
        "русские",
        "легкий фон"
      ]
    },
    {
      "artist": "Александр Панайотов",
      "title": "Необыкновенная",
      "rating": 242,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Zucchero",
      "title": "Wonderful Life",
      "rating": 242,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "Zucchero",
      "title": "Baila Morena",
      "rating": 242,
      "tags": [
        "иностранные",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Zivert",
      "title": "Life (remix)",
      "rating": 242,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Vacuum",
      "title": "I Breathe",
      "rating": 242,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Toto Cutugno",
      "title": "L'Italiano",
      "rating": 242,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "The Weeknd",
      "title": "Save Your Tears",
      "rating": 242,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "The Baseballs",
      "title": "This Love (cover)",
      "rating": 242,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Sting",
      "title": "Shape Of My Heart",
      "rating": 242,
      "tags": [
        "иностранные",
        "медляки"
      ]
    },
    {
      "artist": "Stevie Wonder",
      "title": "I Just Called To Say I Love You",
      "rating": 242,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Smash Mouth!",
      "title": "All Star",
      "rating": 242,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Serj Tankian",
      "title": "Sky Is Over",
      "rating": 242,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "Rod Stewart",
      "title": "What A Wonderful World (cover)",
      "rating": 242,
      "tags": [
        "иностранные",
        "легкий фон"
      ]
    },
    {
      "artist": "Robbie Williams",
      "title": "The Road To Mandalay",
      "rating": 242,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Ricchi E Poveri",
      "title": "Cosa Sei",
      "rating": 242,
      "tags": [
        "иностранные",
        "медляки"
      ]
    },
    {
      "artist": "RHCP",
      "title": "Californication",
      "rating": 242,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "Rammstein",
      "title": "Du Hast",
      "rating": 242,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Rag'n'Bone Man",
      "title": "Skin",
      "rating": 242,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "Rag'n'Bone Man",
      "title": "Human",
      "rating": 242,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "Radiohead",
      "title": "Creep",
      "rating": 242,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "R.E.M",
      "title": "Losing My Religion",
      "rating": 242,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Pharrell Williams",
      "title": "Happy",
      "rating": 242,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Perry Como",
      "title": "Magic moments",
      "rating": 242,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "O-Zone",
      "title": "Dragostea Din Tei",
      "rating": 242,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "Niletto, Олег Майами, Леша Свик",
      "title": "Не вспоминай",
      "rating": 242,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Monatik",
      "title": "УВЛИУВТ",
      "rating": 242,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Minelli",
      "title": "Rampampam",
      "rating": 242,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "Michael Buble",
      "title": "Spiderman Theme",
      "rating": 242,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Michael Buble",
      "title": "Feeling Good (cover)",
      "rating": 242,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "Louis Armstrong",
      "title": "What A Wonderful World",
      "rating": 242,
      "tags": [
        "иностранные",
        "легкий фон"
      ]
    },
    {
      "artist": "Louis Armstrong",
      "title": "Go Down Moses",
      "rating": 242,
      "tags": [
        "иностранные",
        "легкий фон"
      ]
    },
    {
      "artist": "Lost Frequencies",
      "title": "Reality",
      "rating": 242,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Limp Bizkit",
      "title": "Behind Blue Eyes",
      "rating": 242,
      "tags": [
        "иностранные",
        "легкий фон"
      ]
    },
    {
      "artist": "Lenny Kravitz",
      "title": "I Belong To You",
      "rating": 242,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Karen Souza",
      "title": "Get Lucky (cover)",
      "rating": 242,
      "tags": [
        "иностранные",
        "легкий фон"
      ]
    },
    {
      "artist": "Karen Souza",
      "title": "Creep (cover)",
      "rating": 242,
      "tags": [
        "иностранные",
        "легкий фон"
      ]
    },
    {
      "artist": "Juanes",
      "title": "La Camisa Negra",
      "rating": 242,
      "tags": [
        "иностранные",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "James Blunt",
      "title": "You're Beautiful",
      "rating": 242,
      "tags": [
        "иностранные",
        "медляки"
      ]
    },
    {
      "artist": "Hurts",
      "title": "Wonderful Life",
      "rating": 242,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "Harry Styles",
      "title": "Watermelon Sugar",
      "rating": 242,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Green Day",
      "title": "Boulevard of Broken Dreams",
      "rating": 242,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "Gayazovs Brothers",
      "title": "Малиновая Лада",
      "rating": 242,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Filatov & Karas, Burito",
      "title": "Возьми моё сердце",
      "rating": 242,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Eros Ramazzotti",
      "title": "Cose Della Vita",
      "rating": 242,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "Emin",
      "title": "Королева красоты",
      "rating": 242,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Ed Sheeran",
      "title": "Shape Of You",
      "rating": 242,
      "tags": [
        "иностранные",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Eagles",
      "title": "Hotel California (cover)",
      "rating": 242,
      "tags": [
        "иностранные",
        "легкий фон"
      ]
    },
    {
      "artist": "Depeche Mode",
      "title": "Enjoy The Silence",
      "rating": 242,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Dean Martin",
      "title": "Sway",
      "rating": 242,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Coldplay",
      "title": "Adventure Of A Lifetime",
      "rating": 242,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Chris Isaak",
      "title": "Wicked Game",
      "rating": 242,
      "tags": [
        "иностранные",
        "медляки"
      ]
    },
    {
      "artist": "Chris De Burgh",
      "title": "Lady In Red (cover)",
      "rating": 242,
      "tags": [
        "иностранные",
        "медляки"
      ]
    },
    {
      "artist": "Burito",
      "title": "Штрихи",
      "rating": 242,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Burito",
      "title": "Разведи огонь (cover)",
      "rating": 242,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Brainstorm",
      "title": "Maybe",
      "rating": 242,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Boney M",
      "title": "Sunny (cover)",
      "rating": 242,
      "tags": [
        "иностранные",
        "легкий фон"
      ]
    },
    {
      "artist": "Blur",
      "title": "Song 2",
      "rating": 242,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "Andrea Bocelli",
      "title": "Besame Mucho (cover)",
      "rating": 242,
      "tags": [
        "иностранные",
        "легкий фон"
      ]
    },
    {
      "artist": "Aloe Blacc",
      "title": "Wake Me Up (acoustic)",
      "rating": 242,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "Alex Clare",
      "title": "Too Close (acoustic)",
      "rating": 242,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Adriano Celentano",
      "title": "Ja tebia liubliu (Я тебя люблю)",
      "rating": 242,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Уматурман",
      "title": "Проститься",
      "rating": 196,
      "tags": [
        "русские",
        "легкий фон"
      ]
    },
    {
      "artist": "Султан Лагучев",
      "title": "Попутчица (cover)",
      "rating": 196,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Султан Лагучев",
      "title": "Горький вкус",
      "rating": 196,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Руки вверх!",
      "title": "Он тебя целует (ремикс)",
      "rating": 196,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Руки вверх",
      "title": "Ай-яй-яй",
      "rating": 196,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Пикник",
      "title": "У шамана три руки",
      "rating": 196,
      "tags": []
    },
    {
      "artist": "Отпетые мошенники",
      "title": "Люби меня, люби",
      "rating": 196,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Нодар Ревия",
      "title": "Аэропорты",
      "rating": 196,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Найк Борзов",
      "title": "Верхом на звезде",
      "rating": 196,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Мот, Zivert",
      "title": "Паруса",
      "rating": 196,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Михаил Бублик",
      "title": "Дарим сердце",
      "rating": 196,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Михаил Бублик",
      "title": "Артобстрел",
      "rating": 196,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Маша и медведи",
      "title": "Земля",
      "rating": 196,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Леша Свик",
      "title": "Плакала",
      "rating": 196,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Леонид Агутин",
      "title": "Летний дождь",
      "rating": 196,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Король и Шут",
      "title": "Марионетки",
      "rating": 196,
      "tags": []
    },
    {
      "artist": "Звери",
      "title": "Для тебя (cover)",
      "rating": 196,
      "tags": [
        "русские",
        "легкий фон"
      ]
    },
    {
      "artist": "Доминик Джокер",
      "title": "Такая одна",
      "rating": 196,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Дима Билан",
      "title": "Мечтатели",
      "rating": 196,
      "tags": [
        "русские",
        "легкий фон"
      ]
    },
    {
      "artist": "Дима Билан",
      "title": "Держи",
      "rating": 196,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Владимир Пресняков",
      "title": "У тебя есть я",
      "rating": 196,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Ваня Дмитриенко",
      "title": "Венера-Юпитер",
      "rating": 196,
      "tags": [
        "русские",
        "легкий фон"
      ]
    },
    {
      "artist": "Валерий Леонтьев",
      "title": "Девять хризантем",
      "rating": 196,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Браво",
      "title": "Вася",
      "rating": 196,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Арсен Шахунц",
      "title": "Девочка, стоп!",
      "rating": 196,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Ария",
      "title": "Беспечный ангел",
      "rating": 196,
      "tags": [
        "русские",
        "медляки"
      ]
    },
    {
      "artist": "Алексей Чумаков",
      "title": "Назови меня чужим",
      "rating": 196,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Алексей Чумаков",
      "title": "Знаешь",
      "rating": 196,
      "tags": [
        "русские",
        "легкий фон"
      ]
    },
    {
      "artist": "Адлер Коцба, Timran",
      "title": "Запах моей женщины",
      "rating": 196,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Tim Akers, The Smoking Section",
      "title": "Uptown Funk",
      "rating": 196,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "The Interrupters",
      "title": "Bad Guy (cover)",
      "rating": 196,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "The Doors",
      "title": "Riders On The Storm",
      "rating": 196,
      "tags": [
        "иностранные",
        "легкий фон"
      ]
    },
    {
      "artist": "The Calling",
      "title": "Wherever You Will Go",
      "rating": 196,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "Tebey",
      "title": "Blinding Lights (country ver.)",
      "rating": 196,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "RHCP",
      "title": "Scar Tissue",
      "rating": 196,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Reamonn",
      "title": "Supergirl",
      "rating": 196,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "Mr. Credo",
      "title": "Медляк",
      "rating": 196,
      "tags": [
        "русские",
        "медляки"
      ]
    },
    {
      "artist": "Modjo",
      "title": "Lady (cover)",
      "rating": 196,
      "tags": [
        "иностранные",
        "легкий фон"
      ]
    },
    {
      "artist": "Michael Buble",
      "title": "Everything",
      "rating": 196,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Max Oazo, Camishe",
      "title": "Wonderful Life (cover)",
      "rating": 196,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Lee Durley",
      "title": "Unchained Melody (cover)",
      "rating": 196,
      "tags": [
        "иностранные",
        "легкий фон"
      ]
    },
    {
      "artist": "Korn",
      "title": "Freak on a Leash",
      "rating": 196,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "John Legend",
      "title": "All Of Me",
      "rating": 196,
      "tags": [
        "иностранные",
        "легкий фон"
      ]
    },
    {
      "artist": "Jason Mraz",
      "title": "I'm Yours",
      "rating": 196,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Jah Khalib",
      "title": "Созвездие Ангела",
      "rating": 196,
      "tags": [
        "русские",
        "легкий фон"
      ]
    },
    {
      "artist": "Hozier",
      "title": "Take Me To Church",
      "rating": 196,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "Elton John",
      "title": "Original Sin",
      "rating": 196,
      "tags": [
        "иностранные",
        "легкий фон"
      ]
    },
    {
      "artist": "Dan Balan",
      "title": "Лишь до утра",
      "rating": 196,
      "tags": [
        "русские",
        "медляки"
      ]
    },
    {
      "artist": "Burito",
      "title": "Мама (acoustic)",
      "rating": 196,
      "tags": [
        "русские",
        "легкий фон"
      ]
    },
    {
      "artist": "Brainstorm",
      "title": "Ветер",
      "rating": 196,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Bob Dylan",
      "title": "Knockin' On Heaven's Door",
      "rating": 196,
      "tags": [
        "иностранные",
        "легкий фон"
      ]
    },
    {
      "artist": "Avicii",
      "title": "Hey Brother",
      "rating": 196,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Танцы минус",
      "title": "Половинка",
      "rating": 186,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Севак Ханагян",
      "title": "Оставь Себе",
      "rating": 186,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Пицца",
      "title": "Хоп Хэй Лала Лэй (cover)",
      "rating": 186,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Пицца",
      "title": "Улыбка",
      "rating": 186,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Николай Носков",
      "title": "На меньшее я не согласен",
      "rating": 186,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Макс Барских, Zivert",
      "title": "BESTSELLER",
      "rating": 186,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Дима Билан",
      "title": "Я просто люблю тебя",
      "rating": 186,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Артем Качер",
      "title": "Одинокая луна",
      "rating": 186,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Александр Маршал",
      "title": "Орёл",
      "rating": 186,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Zivert",
      "title": "WAKE UP!",
      "rating": 186,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Welshly Arms",
      "title": "Legendary",
      "rating": 186,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "Twenty One Pilots",
      "title": "Stressed Out",
      "rating": 186,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Simply Red",
      "title": "Sunrise",
      "rating": 186,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Sarah Menescal",
      "title": "Adventure Of A Lifetime (cover)",
      "rating": 186,
      "tags": [
        "иностранные",
        "легкий фон"
      ]
    },
    {
      "artist": "Post Malone",
      "title": "Circles",
      "rating": 186,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Ne-Yo",
      "title": "Closer",
      "rating": 186,
      "tags": [
        "иностранные",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Miko",
      "title": "Девочка в тренде",
      "rating": 186,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Lewis Capaldi",
      "title": "Someone You Loved",
      "rating": 186,
      "tags": [
        "иностранные",
        "легкий фон"
      ]
    },
    {
      "artist": "Karen Souza",
      "title": "Safe And Sound (cover)",
      "rating": 186,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Karen Souza",
      "title": "Can't Help Falling In Love (cover)",
      "rating": 186,
      "tags": [
        "иностранные",
        "легкий фон"
      ]
    },
    {
      "artist": "Karen Souza",
      "title": "Ain't No Sunshine (cover)",
      "rating": 186,
      "tags": [
        "иностранные",
        "легкий фон"
      ]
    },
    {
      "artist": "John Legend",
      "title": "All Of Me (cover)",
      "rating": 186,
      "tags": [
        "иностранные",
        "легкий фон"
      ]
    },
    {
      "artist": "James Blunt",
      "title": "Bonfire Heart",
      "rating": 186,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Jah Khalib",
      "title": "Медина",
      "rating": 186,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Hi-Fi",
      "title": "Не дано",
      "rating": 186,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "HammAli & Navai",
      "title": "Прятки",
      "rating": 186,
      "tags": [
        "русские",
        "медляки"
      ]
    },
    {
      "artist": "Fly Project",
      "title": "La Musica",
      "rating": 186,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "Filatov & Karas",
      "title": "Au Au",
      "rating": 186,
      "tags": [
        "иностранные",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Enrique Iglesias",
      "title": "Hero",
      "rating": 186,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Emin",
      "title": "Девочка моя",
      "rating": 186,
      "tags": [
        "русские",
        "легкий фон"
      ]
    },
    {
      "artist": "Ed Sheeran",
      "title": "Bad Habits",
      "rating": 186,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Duke Dumont",
      "title": "Ocean Drive",
      "rating": 186,
      "tags": [
        "иностранные",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Depeche Mode",
      "title": "Precious",
      "rating": 186,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Dabro",
      "title": "Юность",
      "rating": 186,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Burito",
      "title": "Мама",
      "rating": 186,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Billie Eilish",
      "title": "Bad Guy",
      "rating": 186,
      "tags": [
        "иностранные",
        "легкий фон"
      ]
    },
    {
      "artist": "Смысловые галлюцинации",
      "title": "Звёзды 3000",
      "rating": 128,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Сергей Лазарев",
      "title": "Лови",
      "rating": 128,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Нодар Ревия",
      "title": "Салют",
      "rating": 128,
      "tags": [
        "русские"
      ]
    },
    {
      "artist": "Мот",
      "title": "Случайности не случайны",
      "rating": 128,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Машина Времени",
      "title": "За тех, кто в море",
      "rating": 128,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Леонид Агутин",
      "title": "Парень чернокожий",
      "rating": 128,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Илья Киреев",
      "title": "Солдат любви (cover)",
      "rating": 128,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Градусы",
      "title": "Заметает",
      "rating": 128,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Ахра",
      "title": "Карие глаза",
      "rating": 128,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Willy William",
      "title": "Ego",
      "rating": 128,
      "tags": [
        "иностранные",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Twocolors",
      "title": "Lovefool",
      "rating": 128,
      "tags": [
        "иностранные",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Twenty One Pilots",
      "title": "Heathens",
      "rating": 128,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Topic & A7S",
      "title": "Breaking Me",
      "rating": 128,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Robbie Williams",
      "title": "Love My Life",
      "rating": 128,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Ray Charles",
      "title": "Hit The Road Jack",
      "rating": 128,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Lil Nas X, Billy Ray Cyrus",
      "title": "Old Town Road",
      "rating": 128,
      "tags": [
        "иностранные",
        "динамичный фон"
      ]
    },
    {
      "artist": "Jah Khalib",
      "title": "Leila (Лейла Ло)",
      "rating": 128,
      "tags": [
        "русские",
        "медляки"
      ]
    },
    {
      "artist": "J. Balvin, Willy William",
      "title": "Mi Gente",
      "rating": 128,
      "tags": [
        "иностранные",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Gustavo Lima",
      "title": "Balada Boa",
      "rating": 128,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "Frank Sinatra",
      "title": "Fly Me To The Moon",
      "rating": 128,
      "tags": [
        "иностранные",
        "легкий фон"
      ]
    },
    {
      "artist": "Fly Project",
      "title": "Toca Toca",
      "rating": 128,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "Calvin Harris, Rag'n'Bone Man",
      "title": "Giant",
      "rating": 128,
      "tags": [
        "иностранные"
      ]
    },
    {
      "artist": "Burito",
      "title": "Ты всегда ждешь меня",
      "rating": 128,
      "tags": [
        "русские",
        "динамичный фон"
      ]
    },
    {
      "artist": "Burito",
      "title": "Сестричка (cover)",
      "rating": 128,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Burito",
      "title": "По волнам",
      "rating": 128,
      "tags": [
        "русские",
        "танцы",
        "динамичный фон"
      ]
    },
    {
      "artist": "Bobby McFerrin",
      "title": "Don't Worry Be Happy",
      "rating": 128,
      "tags": [
        "иностранные",
        "легкий фон"
      ]
    },
    {
      "artist": "B.J. Thomas",
      "title": "Raindrops Keep Fallin' On My Head",
      "rating": 128,
      "tags": [
        "иностранные",
        "легкий фон"
      ]
    }
  ]
}