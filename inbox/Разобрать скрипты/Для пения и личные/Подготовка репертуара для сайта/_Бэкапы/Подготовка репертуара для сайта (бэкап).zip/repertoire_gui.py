#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Графическая обработка CSV-репертуара.

Возможности:
- перетаскивание CSV-файла в окно;
- выбор CSV кнопкой;
- отдельный JSON-файл автозамен;
- объединение дублей по полям "Исполнитель" + "Название";
- объединение тегов без повторов;
- сохранение repertoire_clean.csv и songs.js.

Для Drag & Drop:
    pip install tkinterdnd2

Без tkinterdnd2 программа всё равно работает через кнопку «Выбрать CSV».
"""

from __future__ import annotations

import csv
import json
import re
import sys
from collections import OrderedDict
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple, Union

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

try:
    from tkinterdnd2 import DND_FILES, TkinterDnD
    DND_AVAILABLE = True
except ImportError:
    DND_FILES = None
    TkinterDnD = None
    DND_AVAILABLE = False


INPUT_DELIMITER = ";"
TAG_DELIMITER = ";"
DEFAULT_REPLACEMENTS = {
    # Язык
    "Я-рус": "русские",
    "я-рус": "русские",
    "Я-англ": "иностранные",
    "Я-ин": "иностранные",

    # Жанр / характер программы
    "к-Релакс": "легкий фон",
    "к-Лаунж": "легкий фон",
    "к-Сред": "легкий фон",
    "к-Медляк": "медляки",
    "к-Динамич": "динамичный фон",
    "к-Мощная": "мощные",
    "к-Танцы&фон": ["танцы", "динамичный фон"],
    "к-Танцы-драйв": ["танцы", "драйв"],
    "к-Танцы-сред": "танцы",

    # Ситуационные / стилевые теги
    "с-НГ": "новогодние",
    "с-90е": "90-е",
    "с-Ретро": "ретро",
    "с-Ром": "романтические",
    "с-Ром-драма": ["романтические", "драматичные"],
    "с-ДляМуж": "для мужчин",

    # Формат репертуара
    "у-Кавказ": "кавказские",
    "у-Мол": "молодежные",
    "у-Народ": "народные",
    "у-РокБар": "рок",
    "у-РокЛегк": ["рок", "легкий рок"],
    "у-Унив": "универсальные",

    # Дополнительные полезные теги
    "н-Позит": "позитивные",
    "н-Груст": "грустные",
    "ж-Латино": "латино",
    "ж-Кавер": "каверы",
    "ж-Рок": "рок"
}


def clean_text(value: object) -> str:
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value)).strip()


def key_text(value: object) -> str:
    return clean_text(value).casefold()


def load_replacements(path: Optional[Path]) -> Dict[str, Union[str, List[str]]]:
    if path is None:
        return dict(DEFAULT_REPLACEMENTS)

    with path.open("r", encoding="utf-8-sig") as file:
        data = json.load(file)

    if not isinstance(data, dict):
        raise ValueError(
            "JSON автозамен должен быть объектом вида "
            "«старое значение»: «новое значение» или список новых значений."
        )

    result: Dict[str, Union[str, List[str]]] = {}

    for old, new in data.items():
        old_text = clean_text(old)
        if not old_text:
            continue

        if isinstance(new, list):
            values = [clean_text(item) for item in new]
            values = [item for item in values if item]
            result[old_text] = values
        else:
            result[old_text] = clean_text(new)

    return result


def expand_replacement(
    tag: str,
    replacements: Dict[str, Union[str, List[str]]],
    only_replaced: bool,
) -> List[str]:
    if tag not in replacements:
        return [] if only_replaced else [tag]

    replacement = replacements[tag]

    if isinstance(replacement, list):
        return [
            clean_text(item)
            for item in replacement
            if clean_text(item)
        ]

    replacement_text = clean_text(replacement)
    return [replacement_text] if replacement_text else []


def split_tags(
    value: object,
    replacements: Dict[str, Union[str, List[str]]],
    only_replaced: bool,
) -> List[str]:
    if value is None:
        return []

    result: List[str] = []
    seen = set()

    for raw_tag in str(value).split(TAG_DELIMITER):
        tag = clean_text(raw_tag)
        if not tag:
            continue

        for expanded in expand_replacement(tag, replacements, only_replaced):
            normalized = expanded.casefold()
            if normalized not in seen:
                seen.add(normalized)
                result.append(expanded)

    return result


def split_and_merge_fields(
    tags_value: object,
    genre_value: object,
    replacements: Dict[str, Union[str, List[str]]],
    only_replaced: bool,
) -> List[str]:
    result = split_tags(tags_value, replacements, only_replaced)
    merge_unique(result, split_tags(genre_value, replacements, only_replaced))
    return result


def merge_unique(existing: List[str], incoming: Iterable[str]) -> None:
    seen = {tag.casefold() for tag in existing}

    for tag in incoming:
        normalized = tag.casefold()
        if normalized not in seen:
            seen.add(normalized)
            existing.append(tag)


def parse_rating(value: object) -> Optional[float]:
    text = clean_text(value).replace(",", ".")
    if not text:
        return None

    try:
        return float(text)
    except ValueError:
        return None


def format_rating(value: Optional[float]) -> str:
    if value is None:
        return ""
    if value.is_integer():
        return str(int(value))
    return str(value)


def choose_rating(current: Optional[float], incoming: Optional[float], mode: str) -> Optional[float]:
    if mode == "first":
        return current if current is not None else incoming
    if mode == "last":
        return incoming if incoming is not None else current

    values = [value for value in (current, incoming) if value is not None]
    return max(values) if values else None


def read_and_merge(
    input_path: Path,
    replacements: Dict[str, Union[str, List[str]]],
    rating_mode: str,
    only_replaced: bool,
) -> Tuple[List[dict], int, int]:
    merged: "OrderedDict[Tuple[str, str], dict]" = OrderedDict()
    source_rows = 0

    with input_path.open("r", encoding="utf-8-sig", newline="") as file:
        reader = csv.DictReader(file, delimiter=INPUT_DELIMITER)

        required = {"Исполнитель", "Название", "Рейтинг", "Жанр", "Теги"}
        missing = required.difference(reader.fieldnames or [])
        if missing:
            raise ValueError(
                "В CSV отсутствуют обязательные столбцы: "
                + ", ".join(sorted(missing))
            )

        for row in reader:
            source_rows += 1
            artist = clean_text(row.get("Исполнитель"))
            title = clean_text(row.get("Название"))

            if not artist or not title:
                continue

            key = (key_text(artist), key_text(title))
            rating = parse_rating(row.get("Рейтинг"))
            tags = split_and_merge_fields(
                row.get("Теги"),
                row.get("Жанр"),
                replacements,
                only_replaced,
            )

            if key not in merged:
                merged[key] = {
                    "Исполнитель": artist,
                    "Название": title,
                    "Рейтинг": rating,
                    "Теги": tags,
                    "_merged_rows": 1,
                }
            else:
                item = merged[key]
                item["Рейтинг"] = choose_rating(item["Рейтинг"], rating, rating_mode)
                merge_unique(item["Теги"], tags)
                item["_merged_rows"] += 1

    items = list(merged.values())
    removed_rows = sum(item["_merged_rows"] - 1 for item in items)
    return items, source_rows, removed_rows


def save_clean_csv(items: List[dict], output_path: Path) -> None:
    with output_path.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(
            file,
            fieldnames=["Исполнитель", "Название", "Рейтинг", "Теги"],
            delimiter=INPUT_DELIMITER,
            quoting=csv.QUOTE_ALL,
        )
        writer.writeheader()

        for item in items:
            writer.writerow(
                {
                    "Исполнитель": item["Исполнитель"],
                    "Название": item["Название"],
                    "Рейтинг": format_rating(item["Рейтинг"]),
                    "Теги": "; ".join(item["Теги"]),
                }
            )


def save_songs_js(items: List[dict], output_path: Path) -> None:
    songs = [
        {
            "artist": item["Исполнитель"],
            "title": item["Название"],
            "tags": item["Теги"],
        }
        for item in items
    ]

    content = "window.SONGS = " + json.dumps(
        songs,
        ensure_ascii=False,
        indent=2,
    ) + ";\n"

    output_path.write_text(content, encoding="utf-8")


class RepertoireApp:
    def __init__(self) -> None:
        root_class = TkinterDnD.Tk if DND_AVAILABLE else tk.Tk
        self.root = root_class()
        self.root.title("Подготовка репертуара")
        self.root.geometry("760x560")
        self.root.minsize(660, 500)

        self.csv_path: Optional[Path] = None
        self.replacements_path: Optional[Path] = None

        self.csv_var = tk.StringVar(value="CSV не выбран")
        self.replacements_var = tk.StringVar(value="Используются встроенные автозамены")
        self.status_var = tk.StringVar(value="Перетащите CSV в окно или выберите его кнопкой.")
        self.rating_mode_var = tk.StringVar(value="max")
        self.save_csv_var = tk.BooleanVar(value=True)
        self.save_js_var = tk.BooleanVar(value=True)
        self.only_replaced_var = tk.BooleanVar(value=True)

        self._build_ui()
        self._setup_drag_drop()

    def _build_ui(self) -> None:
        self.root.configure(bg="#11151b")

        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure("TFrame", background="#11151b")
        style.configure("Card.TFrame", background="#1a1f27")
        style.configure(
            "Title.TLabel",
            background="#11151b",
            foreground="#f5f7fa",
            font=("Segoe UI", 20, "bold"),
        )
        style.configure(
            "Subtitle.TLabel",
            background="#11151b",
            foreground="#aab2bf",
            font=("Segoe UI", 10),
        )
        style.configure(
            "CardTitle.TLabel",
            background="#1a1f27",
            foreground="#f5f7fa",
            font=("Segoe UI", 11, "bold"),
        )
        style.configure(
            "CardText.TLabel",
            background="#1a1f27",
            foreground="#cbd2dc",
            font=("Segoe UI", 10),
        )
        style.configure(
            "Status.TLabel",
            background="#11151b",
            foreground="#71ddd3",
            font=("Segoe UI", 10),
        )
        style.configure("TCheckbutton", background="#11151b", foreground="#f5f7fa")
        style.configure("TRadiobutton", background="#11151b", foreground="#f5f7fa")
        style.configure("Accent.TButton", font=("Segoe UI", 11, "bold"), padding=(16, 11))
        style.configure("TButton", font=("Segoe UI", 10), padding=(12, 8))

        wrapper = ttk.Frame(self.root, padding=24)
        wrapper.pack(fill="both", expand=True)

        ttk.Label(wrapper, text="Подготовка репертуара", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            wrapper,
            text="Объединение дублей, слияние Жанра с Тегами и фильтрация по автозаменам",
            style="Subtitle.TLabel",
        ).pack(anchor="w", pady=(4, 18))

        self.drop_frame = ttk.Frame(wrapper, style="Card.TFrame", padding=24)
        self.drop_frame.pack(fill="x")

        ttk.Label(
            self.drop_frame,
            text="Перетащите сюда CSV-файл",
            style="CardTitle.TLabel",
        ).pack()

        ttk.Label(
            self.drop_frame,
            text="или выберите файл вручную",
            style="CardText.TLabel",
        ).pack(pady=(5, 12))

        ttk.Button(
            self.drop_frame,
            text="Выбрать CSV",
            command=self.choose_csv,
        ).pack()

        ttk.Label(
            self.drop_frame,
            textvariable=self.csv_var,
            style="CardText.TLabel",
            wraplength=640,
        ).pack(pady=(12, 0))

        replacements_frame = ttk.Frame(wrapper, style="Card.TFrame", padding=18)
        replacements_frame.pack(fill="x", pady=(14, 0))

        row = ttk.Frame(replacements_frame, style="Card.TFrame")
        row.pack(fill="x")

        ttk.Label(
            row,
            text="Файл автозамен JSON",
            style="CardTitle.TLabel",
        ).pack(side="left")

        ttk.Button(
            row,
            text="Выбрать JSON",
            command=self.choose_replacements,
        ).pack(side="right")

        ttk.Button(
            row,
            text="Сбросить",
            command=self.clear_replacements,
        ).pack(side="right", padx=(0, 8))

        ttk.Label(
            replacements_frame,
            textvariable=self.replacements_var,
            style="CardText.TLabel",
            wraplength=640,
        ).pack(anchor="w", pady=(10, 0))

        settings = ttk.Frame(wrapper)
        settings.pack(fill="x", pady=(18, 0))

        left = ttk.Frame(settings)
        left.pack(side="left", fill="x", expand=True)

        ttk.Label(
            left,
            text="Рейтинг у дублей:",
            style="Subtitle.TLabel",
        ).pack(anchor="w")

        radio_row = ttk.Frame(left)
        radio_row.pack(anchor="w", pady=(6, 0))

        ttk.Radiobutton(
            radio_row,
            text="максимальный",
            variable=self.rating_mode_var,
            value="max",
        ).pack(side="left")

        ttk.Radiobutton(
            radio_row,
            text="из первой строки",
            variable=self.rating_mode_var,
            value="first",
        ).pack(side="left", padx=(12, 0))

        ttk.Radiobutton(
            radio_row,
            text="из последней строки",
            variable=self.rating_mode_var,
            value="last",
        ).pack(side="left", padx=(12, 0))

        right = ttk.Frame(settings)
        right.pack(side="right", anchor="n")

        ttk.Checkbutton(
            right,
            text="Создать очищенный CSV",
            variable=self.save_csv_var,
        ).pack(anchor="w")

        ttk.Checkbutton(
            right,
            text="Создать songs.js",
            variable=self.save_js_var,
        ).pack(anchor="w", pady=(5, 0))

        ttk.Checkbutton(
            right,
            text="Оставлять только теги из автозамен",
            variable=self.only_replaced_var,
        ).pack(anchor="w", pady=(5, 0))

        ttk.Button(
            wrapper,
            text="Обработать файл",
            style="Accent.TButton",
            command=self.process,
        ).pack(fill="x", pady=(22, 0))

        ttk.Label(
            wrapper,
            textvariable=self.status_var,
            style="Status.TLabel",
            wraplength=700,
        ).pack(anchor="w", pady=(14, 0))

        note = (
            "Для перетаскивания файлов нужен пакет tkinterdnd2. "
            "Без него кнопка выбора файла продолжает работать."
        )
        ttk.Label(
            wrapper,
            text=note,
            style="Subtitle.TLabel",
            wraplength=700,
        ).pack(anchor="w", side="bottom", pady=(18, 0))

    def _setup_drag_drop(self) -> None:
        if not DND_AVAILABLE:
            return

        self.drop_frame.drop_target_register(DND_FILES)
        self.drop_frame.dnd_bind("<<Drop>>", self._on_drop)

    def _on_drop(self, event: object) -> None:
        raw = getattr(event, "data", "")
        paths = self.root.tk.splitlist(raw)

        if not paths:
            return

        path = Path(paths[0])

        if path.suffix.lower() != ".csv":
            messagebox.showerror("Неверный файл", "Перетащите CSV-файл.")
            return

        self.set_csv(path)

    def choose_csv(self) -> None:
        filename = filedialog.askopenfilename(
            title="Выберите CSV-файл",
            filetypes=[("CSV-файлы", "*.csv"), ("Все файлы", "*.*")],
        )
        if filename:
            self.set_csv(Path(filename))

    def set_csv(self, path: Path) -> None:
        self.csv_path = path
        self.csv_var.set(str(path))
        self.status_var.set("CSV выбран. Можно нажимать «Обработать файл».")

    def choose_replacements(self) -> None:
        filename = filedialog.askopenfilename(
            title="Выберите JSON автозамен",
            filetypes=[("JSON-файлы", "*.json"), ("Все файлы", "*.*")],
        )
        if filename:
            self.replacements_path = Path(filename)
            self.replacements_var.set(str(self.replacements_path))

    def clear_replacements(self) -> None:
        self.replacements_path = None
        self.replacements_var.set("Используются встроенные автозамены")

    def process(self) -> None:
        if self.csv_path is None:
            messagebox.showwarning("CSV не выбран", "Сначала выберите или перетащите CSV-файл.")
            return

        if not self.save_csv_var.get() and not self.save_js_var.get():
            messagebox.showwarning("Нет результата", "Выберите хотя бы один выходной файл.")
            return

        try:
            replacements = load_replacements(self.replacements_path)
            items, source_rows, removed_rows = read_and_merge(
                self.csv_path,
                replacements,
                self.rating_mode_var.get(),
                self.only_replaced_var.get(),
            )

            output_dir = self.csv_path.parent
            created: List[Path] = []

            if self.save_csv_var.get():
                clean_csv = output_dir / "repertoire_clean.csv"
                save_clean_csv(items, clean_csv)
                created.append(clean_csv)

            if self.save_js_var.get():
                songs_js = output_dir / "songs.js"
                save_songs_js(items, songs_js)
                created.append(songs_js)

            summary = (
                f"Готово. Исходных строк: {source_rows}. "
                f"Уникальных песен: {len(items)}. "
                f"Удалено дублей: {removed_rows}."
            )
            self.status_var.set(summary)

            files_text = "\n".join(str(path) for path in created)
            messagebox.showinfo(
                "Обработка завершена",
                summary + "\n\nСозданы файлы:\n" + files_text,
            )

        except Exception as error:
            self.status_var.set("Ошибка обработки.")
            messagebox.showerror("Ошибка", str(error))

    def run(self) -> None:
        self.root.mainloop()


def main() -> int:
    app = RepertoireApp()
    app.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
