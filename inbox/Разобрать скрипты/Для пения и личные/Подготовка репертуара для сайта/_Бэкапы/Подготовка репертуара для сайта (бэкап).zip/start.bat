@echo off
python "%~dp0repertoire_gui.py"
if errorlevel 1 pause
