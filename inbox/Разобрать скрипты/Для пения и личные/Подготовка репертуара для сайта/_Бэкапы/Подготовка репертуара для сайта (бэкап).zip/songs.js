window.SONGS = [
  {
    "artist": "Adriano Celentano",
    "title": "Ja tebia liubliu (Я тебя люблю)",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Adriano Celentano",
    "title": "Soli",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Alex Clare",
    "title": "Too Close (acoustic)",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Aloe Blacc",
    "title": "Wake Me Up (acoustic)",
    "tags": [
      "иностранные",
      "мощные"
    ]
  },
  {
    "artist": "Andrea Bocelli",
    "title": "Besame Mucho (cover)",
    "tags": [
      "иностранные",
      "легкий фон"
    ]
  },
  {
    "artist": "Andy Williams",
    "title": "Can't Take My Eyes Off You",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Avicii",
    "title": "Hey Brother",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "B.J. Thomas",
    "title": "Raindrops Keep Fallin' On My Head",
    "tags": [
      "иностранные",
      "легкий фон"
    ]
  },
  {
    "artist": "Berk & The Virtual Band",
    "title": "Sex Bomb (cover)",
    "tags": [
      "иностранные",
      "легкий фон"
    ]
  },
  {
    "artist": "Billie Eilish",
    "title": "Bad Guy",
    "tags": [
      "иностранные",
      "легкий фон"
    ]
  },
  {
    "artist": "Blur",
    "title": "Song 2",
    "tags": [
      "рок",
      "иностранные",
      "танцы"
    ]
  },
  {
    "artist": "Bob Dylan",
    "title": "Knockin' On Heaven's Door",
    "tags": [
      "иностранные",
      "легкий фон"
    ]
  },
  {
    "artist": "Bobby McFerrin",
    "title": "Don't Worry Be Happy",
    "tags": [
      "иностранные",
      "легкий фон"
    ]
  },
  {
    "artist": "Boney M",
    "title": "Sunny (cover)",
    "tags": [
      "иностранные",
      "легкий фон"
    ]
  },
  {
    "artist": "Brainstorm",
    "title": "Maybe",
    "tags": [
      "легкий рок",
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Brainstorm",
    "title": "Ветер",
    "tags": [
      "легкий рок",
      "русские"
    ]
  },
  {
    "artist": "Burito",
    "title": "Мама (acoustic)",
    "tags": [
      "русские",
      "легкий фон"
    ]
  },
  {
    "artist": "Burito",
    "title": "Мама",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Burito",
    "title": "По волнам",
    "tags": [
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Burito",
    "title": "Разведи огонь (cover)",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Burito",
    "title": "Сестричка (cover)",
    "tags": [
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Burito",
    "title": "Ты всегда ждешь меня",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Burito",
    "title": "Штрихи",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Calvin Harris, Rag'n'Bone Man",
    "title": "Giant",
    "tags": [
      "иностранные",
      "мощные"
    ]
  },
  {
    "artist": "Chebanov",
    "title": "Ночь (cover)",
    "tags": [
      "русские",
      "легкий фон"
    ]
  },
  {
    "artist": "Chris De Burgh",
    "title": "Lady In Red (cover)",
    "tags": [
      "иностранные",
      "медляки"
    ]
  },
  {
    "artist": "Chris Isaak",
    "title": "Wicked Game",
    "tags": [
      "иностранные",
      "медляки"
    ]
  },
  {
    "artist": "Coldplay",
    "title": "Adventure Of A Lifetime",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Dabro",
    "title": "Юность",
    "tags": [
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Dan Balan",
    "title": "Лишь до утра",
    "tags": [
      "русские",
      "медляки"
    ]
  },
  {
    "artist": "Dean Martin",
    "title": "Sway",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Depeche Mode",
    "title": "Enjoy The Silence",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Duke Dumont",
    "title": "Ocean Drive",
    "tags": [
      "иностранные",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Eagles",
    "title": "Hotel California (cover)",
    "tags": [
      "иностранные",
      "легкий фон"
    ]
  },
  {
    "artist": "Ed Sheeran",
    "title": "Bad Habits",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Ed Sheeran",
    "title": "Shape Of You",
    "tags": [
      "иностранные",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Elton John",
    "title": "Original Sin",
    "tags": [
      "иностранные",
      "легкий фон"
    ]
  },
  {
    "artist": "Emin",
    "title": "Девочка моя",
    "tags": [
      "русские",
      "легкий фон"
    ]
  },
  {
    "artist": "Emin",
    "title": "Королева красоты",
    "tags": [
      "русские",
      "ретро",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Enrique Iglesias",
    "title": "Hero",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Enrique Iglesias",
    "title": "Love To See You Cry",
    "tags": [
      "иностранные",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Eros Ramazzotti",
    "title": "Cose Della Vita",
    "tags": [
      "иностранные",
      "мощные"
    ]
  },
  {
    "artist": "Filatov & Karas",
    "title": "Au Au",
    "tags": [
      "иностранные",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Filatov & Karas ft. Burito",
    "title": "Возьми моё сердце",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Fly Project",
    "title": "La Musica",
    "tags": [
      "иностранные",
      "танцы"
    ]
  },
  {
    "artist": "Fly Project",
    "title": "Toca Toca",
    "tags": [
      "иностранные",
      "танцы"
    ]
  },
  {
    "artist": "Frank Sinatra",
    "title": "Fly Me To The Moon",
    "tags": [
      "иностранные",
      "легкий фон"
    ]
  },
  {
    "artist": "Galibri & Mavik",
    "title": "Федерико Феллини",
    "tags": [
      "русские",
      "танцы"
    ]
  },
  {
    "artist": "Gayazovs Brothers",
    "title": "Малиновая Лада",
    "tags": [
      "молодежные",
      "русские",
      "танцы"
    ]
  },
  {
    "artist": "Giorgos Mazonakis",
    "title": "Sabbato",
    "tags": [
      "иностранные",
      "медляки"
    ]
  },
  {
    "artist": "Goartur",
    "title": "Иностранец (cover)",
    "tags": [
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Green Day",
    "title": "Boulevard of Broken Dreams",
    "tags": [
      "рок",
      "иностранные"
    ]
  },
  {
    "artist": "Gustavo Lima",
    "title": "Balada Boa",
    "tags": [
      "иностранные",
      "танцы"
    ]
  },
  {
    "artist": "HammAli & Navai",
    "title": "Прятки",
    "tags": [
      "русские",
      "медляки"
    ]
  },
  {
    "artist": "Harry Styles",
    "title": "Watermelon Sugar",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Hi-Fi",
    "title": "Не дано",
    "tags": [
      "русские",
      "90-е",
      "танцы"
    ]
  },
  {
    "artist": "Hozier",
    "title": "Take Me To Church",
    "tags": [
      "иностранные",
      "мощные"
    ]
  },
  {
    "artist": "Hurts",
    "title": "Wonderful Life",
    "tags": [
      "иностранные",
      "мощные"
    ]
  },
  {
    "artist": "J. Balvin; Willy William",
    "title": "Mi Gente",
    "tags": [
      "иностранные",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Jah Khalib",
    "title": "Leila (Лейла Ло)",
    "tags": [
      "русские",
      "медляки"
    ]
  },
  {
    "artist": "Jah Khalib",
    "title": "Медина",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Jah Khalib",
    "title": "Созвездие Ангела",
    "tags": [
      "русские",
      "легкий фон"
    ]
  },
  {
    "artist": "James Blunt",
    "title": "Bonfire Heart",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "James Blunt",
    "title": "You're Beautiful",
    "tags": [
      "иностранные",
      "медляки"
    ]
  },
  {
    "artist": "Jason Mraz",
    "title": "I'm Yours",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "John Legend",
    "title": "All Of Me (cover)",
    "tags": [
      "иностранные",
      "легкий фон"
    ]
  },
  {
    "artist": "John Legend",
    "title": "All Of Me",
    "tags": [
      "иностранные",
      "легкий фон"
    ]
  },
  {
    "artist": "Jony",
    "title": "Комета (cover)",
    "tags": [
      "русские",
      "мощные"
    ]
  },
  {
    "artist": "Jony",
    "title": "Комета",
    "tags": [
      "русские",
      "мощные"
    ]
  },
  {
    "artist": "JP Cooper",
    "title": "She's On My Mind",
    "tags": [
      "иностранные",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Juanes",
    "title": "La Camisa Negra",
    "tags": [
      "иностранные",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Kaleo",
    "title": "Way Down We Go",
    "tags": [
      "иностранные",
      "мощные"
    ]
  },
  {
    "artist": "Karen Souza",
    "title": "Ain't No Sunshine (cover)",
    "tags": [
      "иностранные",
      "легкий фон"
    ]
  },
  {
    "artist": "Karen Souza",
    "title": "Can't Help Falling In Love (cover)",
    "tags": [
      "иностранные",
      "легкий фон"
    ]
  },
  {
    "artist": "Karen Souza",
    "title": "Creep (cover)",
    "tags": [
      "иностранные",
      "легкий фон"
    ]
  },
  {
    "artist": "Karen Souza",
    "title": "Get Lucky (cover)",
    "tags": [
      "иностранные",
      "легкий фон"
    ]
  },
  {
    "artist": "Karen Souza",
    "title": "Safe And Sound (cover)",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Korn",
    "title": "Freak on a Leash",
    "tags": [
      "рок",
      "иностранные"
    ]
  },
  {
    "artist": "Lee Durley",
    "title": "Unchained Melody (cover)",
    "tags": [
      "иностранные",
      "легкий фон"
    ]
  },
  {
    "artist": "Lenny Kravitz",
    "title": "I Belong To You",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Lewis Capaldi",
    "title": "Someone You Loved",
    "tags": [
      "иностранные",
      "легкий фон"
    ]
  },
  {
    "artist": "Lil Nas X; Billy Ray Cyrus",
    "title": "Old Town Road",
    "tags": [
      "молодежные",
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Limp Bizkit",
    "title": "Behind Blue Eyes",
    "tags": [
      "легкий рок",
      "иностранные",
      "легкий фон"
    ]
  },
  {
    "artist": "LOBODA",
    "title": "Текила-любовь (cover)",
    "tags": [
      "русские",
      "мощные"
    ]
  },
  {
    "artist": "Lost Frequencies",
    "title": "Reality",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Louis Armstrong",
    "title": "Go Down Moses",
    "tags": [
      "иностранные",
      "легкий фон"
    ]
  },
  {
    "artist": "Louis Armstrong",
    "title": "What A Wonderful World",
    "tags": [
      "иностранные",
      "легкий фон"
    ]
  },
  {
    "artist": "Maneskin",
    "title": "Beggin'",
    "tags": [
      "иностранные",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Maroon 5",
    "title": "She Will Be Loved",
    "tags": [
      "иностранные",
      "медляки"
    ]
  },
  {
    "artist": "Max Oazo, Camishe",
    "title": "Wonderful Life (cover)",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Michael Buble",
    "title": "Everything",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Michael Buble",
    "title": "Feeling Good (cover)",
    "tags": [
      "иностранные",
      "мощные"
    ]
  },
  {
    "artist": "Michael Buble",
    "title": "Spiderman Theme",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Miko",
    "title": "Девочка в тренде",
    "tags": [
      "молодежные",
      "русские",
      "танцы"
    ]
  },
  {
    "artist": "Minelli",
    "title": "Rampampam",
    "tags": [
      "иностранные",
      "танцы"
    ]
  },
  {
    "artist": "Modjo",
    "title": "Lady (cover)",
    "tags": [
      "иностранные",
      "легкий фон"
    ]
  },
  {
    "artist": "Monatik",
    "title": "УВЛИУВТ",
    "tags": [
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Mr. Credo",
    "title": "Медляк",
    "tags": [
      "русские",
      "медляки"
    ]
  },
  {
    "artist": "Mr. Credo",
    "title": "Чудная долина",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Ne-Yo",
    "title": "Closer",
    "tags": [
      "иностранные",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Niletto; Олег Майами; Леша Свик",
    "title": "Не вспоминай",
    "tags": [
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Ofenbach",
    "title": "Be Mine",
    "tags": [
      "иностранные",
      "танцы"
    ]
  },
  {
    "artist": "O-Zone",
    "title": "Dragostea Din Tei",
    "tags": [
      "иностранные",
      "ретро",
      "танцы"
    ]
  },
  {
    "artist": "Perry Como",
    "title": "Magic moments",
    "tags": [
      "иностранные",
      "новогодние",
      "динамичный фон"
    ]
  },
  {
    "artist": "Pharrell Williams",
    "title": "Happy",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Post Malone",
    "title": "Circles",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "R.E.M",
    "title": "Losing My Religion",
    "tags": [
      "легкий рок",
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Radiohead",
    "title": "Creep",
    "tags": [
      "рок",
      "иностранные"
    ]
  },
  {
    "artist": "Rag'n'Bone Man",
    "title": "Human",
    "tags": [
      "иностранные",
      "мощные"
    ]
  },
  {
    "artist": "Rag'n'Bone Man",
    "title": "Skin",
    "tags": [
      "иностранные",
      "мощные"
    ]
  },
  {
    "artist": "Rammstein",
    "title": "Du Hast",
    "tags": [
      "рок",
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Ray Charles",
    "title": "Hit The Road Jack",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Reamonn",
    "title": "Supergirl",
    "tags": [
      "иностранные",
      "мощные"
    ]
  },
  {
    "artist": "Reamonn",
    "title": "Tonight",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "RHCP",
    "title": "Californication",
    "tags": [
      "легкий рок",
      "иностранные"
    ]
  },
  {
    "artist": "RHCP",
    "title": "Scar Tissue",
    "tags": [
      "легкий рок",
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Ricchi E Poveri",
    "title": "Cosa Sei",
    "tags": [
      "иностранные",
      "медляки"
    ]
  },
  {
    "artist": "Robbie Williams",
    "title": "Feel",
    "tags": [
      "иностранные",
      "мощные"
    ]
  },
  {
    "artist": "Robbie Williams",
    "title": "Love My Life",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Robbie Williams",
    "title": "The Road To Mandalay",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Rod Stewart",
    "title": "What A Wonderful World (cover)",
    "tags": [
      "иностранные",
      "легкий фон"
    ]
  },
  {
    "artist": "Sarah Menescal",
    "title": "Adventure Of A Lifetime (cover)",
    "tags": [
      "иностранные",
      "легкий фон"
    ]
  },
  {
    "artist": "Serj Tankian",
    "title": "Sky Is Over",
    "tags": [
      "рок",
      "иностранные"
    ]
  },
  {
    "artist": "Simply Red",
    "title": "Sunrise",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Smash Mouth!",
    "title": "All Star",
    "tags": [
      "легкий рок",
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Stevie Wonder",
    "title": "I Just Called To Say I Love You",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Sting",
    "title": "Englishman In New York",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Sting",
    "title": "Every Breath You Take",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Sting",
    "title": "Shape Of My Heart",
    "tags": [
      "иностранные",
      "медляки"
    ]
  },
  {
    "artist": "Tebey",
    "title": "Blinding Lights (country ver.)",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "The Baseballs",
    "title": "This Love (cover)",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "The Calling",
    "title": "Wherever You Will Go",
    "tags": [
      "легкий рок",
      "иностранные"
    ]
  },
  {
    "artist": "The Doors",
    "title": "Riders On The Storm",
    "tags": [
      "иностранные",
      "легкий фон"
    ]
  },
  {
    "artist": "The Interrupters",
    "title": "Bad Guy (cover)",
    "tags": [
      "рок",
      "иностранные"
    ]
  },
  {
    "artist": "The Overtones",
    "title": "Pretty Woman (cover)",
    "tags": [
      "иностранные",
      "ретро",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "The Weeknd",
    "title": "Save Your Tears",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Tim Akers; The Smoking Section",
    "title": "Uptown Funk",
    "tags": [
      "иностранные",
      "мощные"
    ]
  },
  {
    "artist": "Tito & Tarantula",
    "title": "After Dark",
    "tags": [
      "легкий рок",
      "иностранные"
    ]
  },
  {
    "artist": "Topic & A7S",
    "title": "Breaking Me",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Toto Cutugno",
    "title": "L'Italiano",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Twenty One Pilots",
    "title": "Heathens",
    "tags": [
      "молодежные",
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Twenty One Pilots",
    "title": "Stressed Out",
    "tags": [
      "молодежные",
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Twocolors",
    "title": "Lovefool",
    "tags": [
      "иностранные",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Vacuum",
    "title": "I Breathe",
    "tags": [
      "иностранные",
      "динамичный фон"
    ]
  },
  {
    "artist": "Welshly Arms",
    "title": "Legendary",
    "tags": [
      "иностранные",
      "мощные"
    ]
  },
  {
    "artist": "Willy William",
    "title": "Ego",
    "tags": [
      "иностранные",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Zivert",
    "title": "Life (remix)",
    "tags": [
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Zivert",
    "title": "WAKE UP!",
    "tags": [
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Zucchero",
    "title": "Baila Morena",
    "tags": [
      "иностранные",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Zucchero",
    "title": "Wonderful Life",
    "tags": [
      "иностранные",
      "мощные"
    ]
  },
  {
    "artist": "А. Беляев",
    "title": "Лететь (cover)",
    "tags": [
      "русские",
      "легкий фон"
    ]
  },
  {
    "artist": "А. Губин",
    "title": "Девушки как звезды",
    "tags": [
      "русские",
      "90-е",
      "танцы"
    ]
  },
  {
    "artist": "А. Губин",
    "title": "Ночь",
    "tags": [
      "русские",
      "90-е",
      "танцы"
    ]
  },
  {
    "artist": "А. Иванов",
    "title": "Боже, Какой Пустяк",
    "tags": [
      "легкий рок",
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "А. Качер",
    "title": "Одинокая луна",
    "tags": [
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "А. Коцба; Timran",
    "title": "Запах моей женщины",
    "tags": [
      "молодежные",
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "А. Панайотов",
    "title": "Необыкновенная",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "А. Чумаков",
    "title": "Знаешь",
    "tags": [
      "русские",
      "легкий фон"
    ]
  },
  {
    "artist": "А. Чумаков",
    "title": "Назови меня чужим",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "А. Чумаков",
    "title": "Счастье",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "А. Чумаков",
    "title": "Тут и там",
    "tags": [
      "русские",
      "легкий фон"
    ]
  },
  {
    "artist": "Александр Маршал",
    "title": "Орёл",
    "tags": [
      "русские",
      "мощные"
    ]
  },
  {
    "artist": "Александр Розенбаум",
    "title": "Ау (cover)",
    "tags": [
      "русские",
      "легкий фон"
    ]
  },
  {
    "artist": "А-Мега",
    "title": "Лететь",
    "tags": [
      "легкий рок",
      "русские",
      "медляки"
    ]
  },
  {
    "artist": "Ария",
    "title": "Беспечный ангел",
    "tags": [
      "легкий рок",
      "русские",
      "медляки"
    ]
  },
  {
    "artist": "Арсен Шахунц",
    "title": "Девочка, стоп!",
    "tags": [
      "кавказ",
      "русские",
      "танцы"
    ]
  },
  {
    "artist": "Ахра",
    "title": "Карие глаза",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Баста",
    "title": "Сансара",
    "tags": [
      "русские",
      "медляки"
    ]
  },
  {
    "artist": "Батырхан Шукенов",
    "title": "Твои шаги",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Браво",
    "title": "Вася",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Браво",
    "title": "Ветер знает",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Браво",
    "title": "Я - то, что надо (cover)",
    "tags": [
      "русские",
      "легкий фон"
    ]
  },
  {
    "artist": "Братья Грим",
    "title": "Ресницы",
    "tags": [
      "легкий рок",
      "русские"
    ]
  },
  {
    "artist": "Бумбокс",
    "title": "Та, что",
    "tags": [
      "русские",
      "легкий фон"
    ]
  },
  {
    "artist": "В. Леонтьев",
    "title": "Девять хризантем",
    "tags": [
      "русские",
      "ретро",
      "танцы"
    ]
  },
  {
    "artist": "В. Леонтьев",
    "title": "Сокровища Чёрного моря",
    "tags": [
      "русские",
      "ретро",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "В. Меладзе",
    "title": "Красиво",
    "tags": [
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "В. Меладзе",
    "title": "Небеса",
    "tags": [
      "русские",
      "мощные"
    ]
  },
  {
    "artist": "В. Меладзе",
    "title": "Притяженья больше нет",
    "tags": [
      "русские",
      "мощные"
    ]
  },
  {
    "artist": "В. Меладзе",
    "title": "Се ля ви",
    "tags": [
      "легкий рок",
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "В. Пресняков",
    "title": "Всё нормально у хулигана",
    "tags": [
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "В. Пресняков",
    "title": "У тебя есть я",
    "tags": [
      "русские",
      "мощные"
    ]
  },
  {
    "artist": "В. Стрыкало",
    "title": "Наше лето",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "В. Сюткин",
    "title": "7000 над землёй",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Ваня Дмитриенко",
    "title": "Венера-Юпитер",
    "tags": [
      "русские",
      "легкий фон"
    ]
  },
  {
    "artist": "Владимир Кузьмин",
    "title": "Эй, красотка",
    "tags": [
      "легкий рок",
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Градусы",
    "title": "Заметает",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Градусы",
    "title": "Режиссёр",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Григорий Лепс",
    "title": "Натали",
    "tags": [
      "русские",
      "медляки"
    ]
  },
  {
    "artist": "Д. Билан",
    "title": "Держи",
    "tags": [
      "русские",
      "танцы"
    ]
  },
  {
    "artist": "Д. Билан",
    "title": "Молния",
    "tags": [
      "русские",
      "танцы"
    ]
  },
  {
    "artist": "Д. Билан",
    "title": "Я просто люблю тебя",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Д. Колдун",
    "title": "Корабли",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "ДДТ",
    "title": "Это всё",
    "tags": [
      "русские",
      "мощные"
    ]
  },
  {
    "artist": "Дима Билан",
    "title": "Мечтатели",
    "tags": [
      "русские",
      "легкий фон"
    ]
  },
  {
    "artist": "Доминик Джокер",
    "title": "Если ты со мной",
    "tags": [
      "русские",
      "медляки"
    ]
  },
  {
    "artist": "Доминик Джокер",
    "title": "Такая одна",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Женя Трофимов",
    "title": "Поезда",
    "tags": [
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Женя Трофимов",
    "title": "Самолеты (remix)",
    "tags": [
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Звери",
    "title": "Для тебя (cover)",
    "tags": [
      "русские",
      "легкий фон"
    ]
  },
  {
    "artist": "Звери",
    "title": "Районы-кварталы",
    "tags": [
      "рок",
      "русские",
      "танцы"
    ]
  },
  {
    "artist": "Звонкий",
    "title": "Голоса",
    "tags": [
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "И. Киреев",
    "title": "Солдат любви (cover)",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "И. Саруханов",
    "title": "Желаю тебе",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Иванушки International",
    "title": "Тополиный Пух",
    "tags": [
      "русские",
      "90-е",
      "танцы"
    ]
  },
  {
    "artist": "Иракли",
    "title": "Капли Абсента",
    "tags": [
      "русские",
      "танцы"
    ]
  },
  {
    "artist": "Король и Шут",
    "title": "Камнем по голове",
    "tags": [
      "рок"
    ]
  },
  {
    "artist": "Король и Шут",
    "title": "Кукла колдуна",
    "tags": [
      "рок",
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Король и Шут",
    "title": "Марионетки",
    "tags": [
      "рок"
    ]
  },
  {
    "artist": "Король и Шут",
    "title": "Танец злобного гения (acoustic)",
    "tags": [
      "рок",
      "русские"
    ]
  },
  {
    "artist": "Л. Агутин",
    "title": "Голос высокой травы",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Л. Агутин",
    "title": "Летний дождь",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Л. Агутин",
    "title": "На сиреневой луне",
    "tags": [
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Л. Агутин",
    "title": "Оле-оле",
    "tags": [
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Л. Агутин",
    "title": "Парень чернокожий",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Л. Агутин",
    "title": "Половина сердца",
    "tags": [
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Л. Агутин",
    "title": "Самба",
    "tags": [
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Л. Агутин",
    "title": "Хоп хэй лала лэй",
    "tags": [
      "русские",
      "танцы"
    ]
  },
  {
    "artist": "Л. Агутин & А. Варум",
    "title": "Я буду всегда с тобой",
    "tags": [
      "русские",
      "легкий фон"
    ]
  },
  {
    "artist": "Ласковый май",
    "title": "Белые розы",
    "tags": [
      "русские",
      "ретро",
      "танцы"
    ]
  },
  {
    "artist": "Ласковый май",
    "title": "Детство",
    "tags": [
      "русские",
      "ретро",
      "танцы"
    ]
  },
  {
    "artist": "Ленинград",
    "title": "WWW",
    "tags": [
      "русские",
      "танцы"
    ]
  },
  {
    "artist": "Ленинград",
    "title": "Рыба моей мечты",
    "tags": [
      "русские",
      "танцы"
    ]
  },
  {
    "artist": "Леприконсы",
    "title": "Хали-гали, Паратрупер",
    "tags": [
      "рок",
      "русские",
      "танцы"
    ]
  },
  {
    "artist": "Леша Свик",
    "title": "Плакала",
    "tags": [
      "русские",
      "мощные"
    ]
  },
  {
    "artist": "Ляпис Трубецкой",
    "title": "Шут",
    "tags": [
      "рок",
      "русские"
    ]
  },
  {
    "artist": "М. Барских",
    "title": "Берега",
    "tags": [
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "М. Барских",
    "title": "Моя любовь",
    "tags": [
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "М. Барских",
    "title": "Туманы",
    "tags": [
      "русские",
      "танцы"
    ]
  },
  {
    "artist": "М. Барских & Zivert",
    "title": "BESTSELLER",
    "tags": [
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "М. Бублик",
    "title": "Артобстрел",
    "tags": [
      "русские",
      "мощные"
    ]
  },
  {
    "artist": "М. Бублик",
    "title": "Дарим сердце",
    "tags": [
      "русские",
      "мощные"
    ]
  },
  {
    "artist": "М. Круженков; Hi-Fi",
    "title": "Седьмой лепесток (cover)",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "М. Насыров",
    "title": "Я это ты",
    "tags": [
      "русские",
      "медляки"
    ]
  },
  {
    "artist": "М. Шуфутинский",
    "title": "Левый берег Дона",
    "tags": [
      "русские",
      "ретро",
      "танцы"
    ]
  },
  {
    "artist": "Мари Краймбрери; Ф. Киркоров",
    "title": "Первый снег (cover)",
    "tags": [
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Маша и медведи",
    "title": "Земля",
    "tags": [
      "рок",
      "русские"
    ]
  },
  {
    "artist": "Машина Времени",
    "title": "За тех, кто в море",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Михаил Боярский",
    "title": "Спасибо, родная",
    "tags": [
      "русские",
      "медляки"
    ]
  },
  {
    "artist": "Михей и Джуманджи",
    "title": "Сука-любовь",
    "tags": [
      "русские",
      "мощные"
    ]
  },
  {
    "artist": "Мот",
    "title": "Случайности не случайны",
    "tags": [
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Мот & Zivert",
    "title": "Паруса",
    "tags": [
      "русские",
      "танцы"
    ]
  },
  {
    "artist": "Н. Носков",
    "title": "На меньшее я не согласен",
    "tags": [
      "русские",
      "мощные"
    ]
  },
  {
    "artist": "Н. Носков",
    "title": "Это здорово (медляк)",
    "tags": [
      "русские",
      "легкий фон"
    ]
  },
  {
    "artist": "Найк Борзов",
    "title": "Верхом на звезде",
    "tags": [
      "рок",
      "русские"
    ]
  },
  {
    "artist": "Нодар Ревия",
    "title": "Аэропорты",
    "tags": [
      "русские",
      "мощные"
    ]
  },
  {
    "artist": "Нодар Ревия",
    "title": "Лала",
    "tags": [
      "русские",
      "легкий фон"
    ]
  },
  {
    "artist": "Нодар Ревия",
    "title": "Не говори ему",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Нодар Ревия",
    "title": "Салют",
    "tags": [
      "русские",
      "мощные"
    ]
  },
  {
    "artist": "Нодар Ревия",
    "title": "Это здорово (cover)",
    "tags": [
      "русские",
      "мощные"
    ]
  },
  {
    "artist": "О. Кензов",
    "title": "По кайфу",
    "tags": [
      "кавказ",
      "русские",
      "танцы"
    ]
  },
  {
    "artist": "Отпетые мошенники",
    "title": "Люби меня, люби",
    "tags": [
      "русские",
      "90-е",
      "танцы"
    ]
  },
  {
    "artist": "Паскаль",
    "title": "Шёлковое сердце",
    "tags": [
      "русские",
      "мощные"
    ]
  },
  {
    "artist": "Пикник",
    "title": "У шамана три руки",
    "tags": [
      "рок"
    ]
  },
  {
    "artist": "Пицца",
    "title": "Лифт",
    "tags": [
      "русские",
      "легкий фон"
    ]
  },
  {
    "artist": "Пицца",
    "title": "Оружие",
    "tags": [
      "русские",
      "медляки"
    ]
  },
  {
    "artist": "Пицца",
    "title": "Пятница",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Пицца",
    "title": "Романс",
    "tags": [
      "русские",
      "легкий фон"
    ]
  },
  {
    "artist": "Пицца",
    "title": "Улыбка",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Пицца",
    "title": "Хоп Хэй Лала Лэй (cover)",
    "tags": [
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Руки вверх",
    "title": "18 мне уже",
    "tags": [
      "русские",
      "90-е",
      "танцы"
    ]
  },
  {
    "artist": "Руки вверх",
    "title": "Ай-яй-яй",
    "tags": [
      "русские",
      "90-е",
      "танцы"
    ]
  },
  {
    "artist": "Руки вверх!",
    "title": "Он тебя целует (ремикс)",
    "tags": [
      "русские",
      "90-е",
      "танцы"
    ]
  },
  {
    "artist": "С. Лазарев",
    "title": "Лови",
    "tags": [
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Севак Ханагян",
    "title": "Если Вдруг",
    "tags": [
      "русские",
      "легкий фон"
    ]
  },
  {
    "artist": "Севак Ханагян",
    "title": "Жди меня там",
    "tags": [
      "русские",
      "мощные"
    ]
  },
  {
    "artist": "Севак Ханагян",
    "title": "Когда мы с тобой",
    "tags": [
      "русские",
      "мощные"
    ]
  },
  {
    "artist": "Севак Ханагян",
    "title": "Оставь Себе",
    "tags": [
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Смысловые галлюцинации",
    "title": "Вечно молодой",
    "tags": [
      "рок",
      "русские"
    ]
  },
  {
    "artist": "Смысловые галлюцинации",
    "title": "Звёзды 3000",
    "tags": [
      "рок",
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Сосо Павлиашвили",
    "title": "Небо на ладони",
    "tags": [
      "русские",
      "мощные"
    ]
  },
  {
    "artist": "Сплин",
    "title": "Выхода нет",
    "tags": [
      "легкий рок",
      "русские",
      "легкий фон",
      "рок"
    ]
  },
  {
    "artist": "Сплин",
    "title": "Моё сердце",
    "tags": [
      "легкий рок",
      "русские",
      "динамичный фон"
    ]
  },
  {
    "artist": "Султан Лагучев",
    "title": "Горький вкус",
    "tags": [
      "кавказ",
      "русские",
      "танцы"
    ]
  },
  {
    "artist": "Султан Лагучев",
    "title": "Попутчица (cover)",
    "tags": [
      "кавказ",
      "русские",
      "танцы",
      "динамичный фон"
    ]
  },
  {
    "artist": "Танцы минус",
    "title": "<НАЗВАНИЕ>",
    "tags": [
      "рок",
      "русские"
    ]
  },
  {
    "artist": "Уматурман",
    "title": "Проститься",
    "tags": [
      "русские",
      "легкий фон"
    ]
  },
  {
    "artist": "Чай вдвоём",
    "title": "Ласковая моя",
    "tags": [
      "русские",
      "медляки"
    ]
  },
  {
    "artist": "ШнАпS Band",
    "title": "Батарейка (cover)",
    "tags": [
      "легкий рок",
      "русские"
    ]
  },
  {
    "artist": "ШнАпS Band",
    "title": "Районы-кварталы (cover)",
    "tags": [
      "рок",
      "русские",
      "танцы"
    ]
  },
  {
    "artist": "ШнАпS Band",
    "title": "Улыбайся (cover)",
    "tags": [
      "рок",
      "русские",
      "танцы"
    ]
  },
  {
    "artist": "Шура",
    "title": "Не верь слезам",
    "tags": [
      "русские",
      "90-е",
      "танцы"
    ]
  }
];
